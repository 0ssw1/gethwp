# Description
HWP 파일을 읽어오는 라이브러리입니다.

## 사용법
```python
import gethwp
hwp = gethwp.read_hwp('test.hwp')
print(hwp)
```

